# AI Gateway — GUI Implementation Spec

**Audience:** Claude Code (or any frontend engineer) implementing the SimCorp AI Gateway web UIs from the HTML prototype in `prototype/`.
**Scope:** Two surfaces — `admin/` (platform-team console) and `portal/` (developer self-service). Reuse one component library across both; theme + nav differ.
**Source of truth:** every screen has a working HTML mock under `prototype/*.html` (admin) and `prototype/portal/*.html` (portal). Pixel-match those. When this doc and the mock disagree, **the mock wins** unless this doc says otherwise.

---

## 0. Stack & conventions

- **Framework:** Next.js 15 (App Router) + React 19 + TypeScript strict.
- **Styling:** Tailwind v4 with CSS variables mapped from `prototype/shared.css` + `prototype/reskin-admin.css` + `prototype/portal/portal.css` + `prototype/portal/reskin-portal.css`. Do NOT re-derive colors; copy the variables.
- **Component lib:** shadcn/ui as the primitive layer (Button, Dialog, DropdownMenu, Tabs, Tooltip, Sheet, Command). Wrap each into `apps/ui/components/<name>.tsx` so theming is centralized.
- **Icons:** lucide-react. Names mapped at the bottom of this doc.
- **Charts:** Recharts (line, bar, area, stacked-bar). For sparklines, a custom 80-byte SVG component (see `prototype/portal/usage.html` for the bar pattern; `prototype/guardrails.html` for the area pattern).
- **State:** React Query for server state, Zustand for ephemeral UI state (filters, panel open/closed, drag selection). No Redux.
- **Forms:** react-hook-form + zod resolvers. Every form has an inline error region above the submit button.
- **Routing:**
  - Admin: `/admin/*` (auth: SimCorp SSO + role `gateway-admin` or `gateway-auditor`).
  - Portal: `/portal/*` (auth: SimCorp SSO; any engineer).
- **Auth:** NextAuth with Entra ID provider; role claims read from `groups` token claim.
- **API:** REST under `/api/v1/*`, OpenAPI 3.1 spec at `services/admin/openapi.yaml`. Generate types with `openapi-typescript`; do not hand-write request/response types.
- **Telemetry:** OpenTelemetry browser SDK; every nav posts a `page.view` event with `surface=admin|portal` and `route`.

---

## 1. Information architecture

### 1.1 Admin surface — `/admin/*`

| Group     | Route                  | Page file in mock              | Purpose                                      |
|-----------|------------------------|--------------------------------|----------------------------------------------|
| Overview  | `/admin/dashboard`     | `dashboard.html`               | Org KPIs, request/cache chart, top teams     |
| Overview  | `/admin/requests`      | `requests.html`                | Live request explorer (streamed)             |
| Govern    | `/admin/teams`         | `teams.html`                   | Team list                                    |
| Govern    | `/admin/teams/[id]`    | `team.html`                    | Team detail (members, keys, quotas, policy)  |
| Govern    | `/admin/policies`      | `policies.html`                | Versioned org/team policies                  |
| Govern    | `/admin/guardrails`    | `guardrails.html`              | Ordered input/output filter pipeline         |
| Govern    | `/admin/quotas`        | `quotas.html`                  | Per-team rate + cost caps, forecast          |
| Govern    | `/admin/approvals`     | `approvals.html`               | Pending publish/install/scope approvals      |
| Catalog   | `/admin/models`        | `models.html`                  | Model registry — capabilities, fallbacks     |
| Catalog   | `/admin/mcp`           | `mcp.html`                     | MCP server registry                          |
| Catalog   | `/admin/skills`        | `skills.html`                  | Skill catalog with publish-rights/freeze     |
| Catalog   | `/admin/plugins`       | `plugins.html`                 | Plugin marketplace + per-team gating         |
| Catalog   | `/admin/cache`         | `cache.html`                   | Semantic cache config + analytics            |
| Catalog   | `/admin/providers`     | `providers.html`               | Upstream provider keys + health              |
| Operate   | `/admin/alerts`        | `alerts.html`                  | Active alerts, rule index, channels          |
| Operate   | `/admin/audit`         | `audit.html`                   | WORM-stored audit log, exportable            |

### 1.2 Portal surface — `/portal/*`

| Group   | Route                     | Page file in mock                | Purpose                                    |
|---------|---------------------------|----------------------------------|--------------------------------------------|
| Use     | `/portal`                 | `portal/home.html`               | Dev home — quick actions, recent activity  |
| Use     | `/portal/playground`      | `portal/playground.html`         | Multi-turn chat playground + params/tools  |
| Build   | `/portal/prompts`         | `portal/prompts.html`            | Org prompt template library                |
| Build   | `/portal/agents`          | `portal/agents.html`             | Personal agent runs / saved agents         |
| Build   | `/portal/mcp`             | `portal/mcp.html`                | MCP server browser (read-only catalog)     |
| Build   | `/portal/skills`          | `portal/skills.html`             | Skill library (read-only)                  |
| Build   | `/portal/plugins`         | `portal/plugins.html`            | Personal plugin install                    |
| Account | `/portal/keys`            | `portal/keys.html`               | API key management                         |
| Account | `/portal/usage`           | `portal/usage.html`              | Personal usage + spend                     |
| Account | `/portal/models`          | `portal/models.html`             | Model browser with copy-snippet            |
| Account | `/portal/docs`            | `portal/docs.html`               | Inline docs — quickstart, guides           |

---

## 2. Shared components (build once, used by both surfaces)

Implement these in `apps/ui/components/` exactly. Token names map to CSS variables already in `shared.css`.

### 2.1 Layout

- **`<Shell>`** — owns the sidebar + topbar slot. Props: `surface: "admin" | "portal"`, `nav: NavGroup[]`, `crumbs: Crumb[]`, `activeId: string`. Renders the layout grid (220px sidebar + 1fr main). Mock: `prototype/shell.js`. Implement two presets `AdminShell` / `PortalShell` that hard-code the nav.
- **`<Topbar>`** — breadcrumbs (left), search (`⌘K`), notifications, user menu. Search opens a Command palette covering teams, models, traces.
- **`<PageHead>`** — `title`, `subtitle`, `actions` slot. 12px gap above filter row.
- **`<FilterBar>`** — horizontal row of `<Filter label value>` chips + spacer + segmented control + optional search input. Mock: `.filters` in shared.css.

### 2.2 Data display

- **`<KpiCard>`** — `label`, `value`, optional `unit`, `delta` (+ direction `up | down | flat`), optional `sparkline`. 4-up grid is `<KpiGrid>`. Match `.kpi` styling.
- **`<DataTable>`** — built on TanStack Table v8. Required props: `columns`, `data`, `getRowId`, optional `onRowClick`, `emptyState`. Column meta: `align: "left" | "right"`, `mono: boolean`, `width: string`. Header sort, multi-row select, sticky first column on horizontal scroll. Match `.tbl` look (1px borders, 13.5px text, hover row highlight).
- **`<Pill variant>`** — variants: `default | info | good | warn | bad`. Adds an optional leading `.dot`. Match `.pill / .pill--good / .pill--warn / .pill--bad / .pill--info`.
- **`<StatusDot status>`** — small color dot for inline status next to a label.
- **`<MetricBar value max>`** — thin progress bar used in quotas + budget cells.
- **`<Sparkline data variant>`** — variants: `line | bar | area`. 80-byte SVG, viewBox `0 0 320 80`. Used in dashboard, guardrails, usage.

### 2.3 Inputs

- **`<Button variant size>`** — variants: `default | primary | ghost | danger`. Sizes: `sm | md`. Map to `.btn / .btn--primary / .btn--sm`.
- **`<SegmentedControl options value onChange>`** — `.seg` look.
- **`<CodeBlock language code copyable>`** — Shiki w/ `nord-dark` theme; copy-to-clipboard top-right.
- **`<JsonViewer value>`** — collapsible JSON tree, used in request explorer + audit detail.

### 2.4 Domain primitives

- **`<TraceLink id>`** — `mono`, navigates to the trace explorer pinned to the request.
- **`<TeamLink id>`** — pill style, links to `/admin/teams/[id]`.
- **`<ModelChip id>`** — provider icon + model name, hover-card with capabilities (context, tools, vision).
- **`<UserAvatar email size>`** — initials fallback with deterministic color.
- **`<MoneyCell amount>`** — `$1,234.56`, monospace, right-aligned.

---

## 3. Data model (TypeScript types)

Place in `packages/contracts/src/`. These are the authoritative shapes — all API responses conform.

```ts
// Shared
type ID = string;            // UUID v7
type ISODate = string;       // RFC3339 UTC
type Money = { cents: number; currency: "USD" | "EUR" | "DKK" };
type Severity = "P1" | "P2" | "P3";
type Status = "good" | "warn" | "bad" | "info";

// Team
type Team = {
  id: ID; name: string; ownerEmail: string;
  members: number; keys: number; tier: "free" | "team" | "enterprise";
  budget: { capCents: number; usedCents: number; periodStart: ISODate };
  status: Status; alerts: ("budget" | "rate" | "drift" | "policy")[];
};

// API key
type ApiKey = {
  id: ID; teamId: ID; label: string; prefix: string;          // "sk_live_8a4f"
  createdAt: ISODate; lastUsedAt: ISODate | null; createdBy: string;
  scopes: string[]; rateLimit: { rpm: number; tpm: number };
  status: "active" | "rotating" | "revoked";
};

// Model
type Model = {
  id: string;                // "anthropic/claude-sonnet-4.5"
  provider: "anthropic" | "openai" | "azure" | "google" | "internal";
  family: string; displayName: string;
  capabilities: { vision: boolean; tools: boolean; thinking: boolean; context: number };
  pricing: { inputCpm: number; outputCpm: number };  // cents per million tok
  fallbacks: string[];                               // ordered model ids
  status: "active" | "deprecated" | "preview";
  region: ("us" | "eu" | "global")[];
};

// MCP server
type McpServer = {
  id: ID; name: string; version: string;
  transport: "stdio" | "http" | "http+sse";
  source: "internal" | "vendored" | "community";
  ownerTeamId: ID;
  tools: { name: string; scope: string; write: boolean }[];
  health: Status; latencyP50Ms: number | null; errorRate: number; calls24h: number;
  approvalState: "approved" | "pending" | "blocked";
};

// Skill
type Skill = {
  id: ID; name: string; description: string;
  ownerTeamId: ID; version: string;
  modelId: string; tools: number;
  visibility: "private" | "team" | "org";
  status: "draft" | "review" | "published" | "frozen" | "blocked";
  uses7d: number;
};

// Plugin
type Plugin = {
  id: ID; name: string; description: string;
  category: "Observability" | "Safety" | "Routing" | "Editor" | "Eval";
  source: "first-party" | "vendored" | "community";
  scope: "required" | "opt-in" | "per-user";
  policyGate: "none" | "cost-cap" | "review" | "blocked";
  status: "enabled" | "available" | "conditional" | "blocked";
  teamsUsing: number; teamsTotal: number;
};

// Request (live explorer)
type Request = {
  traceId: ID; ts: ISODate;
  teamId: ID; userEmail: string; keyPrefix: string;
  modelId: string; route: "direct" | "fallback" | "cache";
  promptTokens: number; completionTokens: number;
  costCents: number; latencyMs: number; ttftMs: number;
  status: "ok" | "blocked" | "error" | "rate-limited";
  guardrailHits: { name: string; action: "block"|"flag"|"redact" }[];
};

// Audit event
type AuditEvent = {
  id: ID; ts: ISODate; actor: { email: string; role: string } | { system: string };
  action: string;            // "policy.update", "key.create", ...
  resource: string;          // "policy/research-eu/budget"
  outcome: "success" | "blocked" | "redacted" | "pending" | "drift";
  traceId: ID;
  diffUrl?: string;          // for diff-able actions
};

// Alert
type Alert = {
  id: ID; severity: Severity; ruleId: ID; ruleName: string;
  triggeredAt: ISODate; firstSeen: ISODate; ownerTeamId: ID | null;
  status: "firing" | "acked" | "resolved";
  ackBy?: string; ackAt?: ISODate;
};
type AlertRule = {
  id: ID; name: string; severity: Severity;
  metric: string;            // "budget.team.monthly", "latency.p95", "guardrail.pii.hits"
  comparator: ">" | "<" | ">=" | "<="; threshold: number; window: string;  // "5m"
  scope: "org" | { teamIds: ID[] };
  channels: ID[]; active: boolean;
};

// Guardrail
type Guardrail = {
  id: ID; name: string; description: string;
  stage: "input" | "output";
  action: "block" | "flag" | "redact" | "rewrite" | "truncate" | "route";
  scope: { include: "org" | ID[]; exclude?: ID[] };
  config: Record<string, unknown>;       // validator-shape varies
  order: number;                         // pipeline order
  hits24h: number; enabled: boolean;
};
```

OpenAPI spec must include `paths` for each resource with `GET /{collection}`, `GET /{collection}/{id}`, `POST`, `PATCH`, and (where applicable) `DELETE`. List endpoints support `?cursor=&limit=&filter=` (filter is a JSON-encoded RHF object).

---

## 4. Pages — page-by-page implementation notes

Every page **MUST** match its mock's layout, copy, columns, filter set, and KPI cards 1:1. Differences below are deliberate runtime behaviors not visible in the static mock.

### 4.1 Admin · Dashboard
- 4 KPI cards (Requests 24h, Spend MTD, Cache hit, Active alerts).
- Requests + cache-hit area chart over a 24h window. Auto-refresh every 30s.
- Top teams table — link rows to `/admin/teams/[id]`.

### 4.2 Admin · Live requests (`requests.html`)
- Server-Sent Events stream from `GET /api/v1/requests/stream`. Reconnect on close with exponential backoff.
- Filters: team, model, status, route, time-range.
- Click row → right-side `<Sheet>` with full trace JSON, prompt/completion side-by-side (output PII redactor must already have run), and "Open in Datadog".
- Pause button freezes the buffer; resume catches up via cursor.

### 4.3 Admin · Teams + Team detail
- Teams table inline with the mock columns.
- Team detail tabs: **Members** · **API keys** · **Quotas** · **Policies** · **Activity**.
- Member add: email-typeahead from Entra; role select (Owner / Editor / Viewer).
- Key create: returns secret **once**; copy-to-clipboard then masked forever. Confirmation modal mentions "save it now".

### 4.4 Admin · Policies
- Versioned policy list. Click row → side-by-side diff view (Monaco diff editor) of versions.
- "Promote to org" requires 2-person approval (creates a row in `approvals.html`).

### 4.5 Admin · Guardrails
- Drag-to-reorder rows reorders pipeline. Optimistic update; rollback on 4xx.
- "Test playground" button → modal with prompt input → server runs full pipeline server-side and returns hits per stage.

### 4.6 Admin · Quotas & budgets
- Per-team rate + cost caps editable inline; show `<MetricBar>` with current usage; show 30-day forecast vs cap as a line chart.
- Bulk edit: select N teams → "Apply preset" (free / team / enterprise).

### 4.7 Admin · Approvals
- Inbox of pending requests: skill publish, MCP scope, plugin install, policy promote.
- Each item has SLA aging color: green ≤24h, amber ≤72h, red >72h.
- Approve / reject inline; reject requires reason text.

### 4.8 Admin · Catalog (Models / MCP / Skills / Plugins / Cache / Providers)
- All five share the same shape: KPI strip + filter bar + table.
- "+ Register / + Submit" CTAs open a step-by-step Sheet form (3–4 steps).
- Health column auto-refreshes from `GET /api/v1/{collection}/{id}/health` every 60s.

### 4.9 Admin · Alerts
- Two-column: active alerts (left, wider) + rule index + channels (right stack).
- Ack inline with optional comment; resolve transitions to history (still reachable via `?status=resolved`).

### 4.10 Admin · Audit log
- Cursor-paginated. Search box hits all fields (actor, resource, trace).
- WORM: rows are immutable. "Diff" opens Monaco-diff for `policy.*`, `model.*`, `team.*` actions.
- Export CSV → background job; toast with download URL when ready.

### 4.11 Portal · Home
- 4 quick-action tiles (Playground · Keys · Models · Docs) with distinct gradient surfaces.
- "Recent activity" feed = last 10 of the user's runs/key-creates.
- Sparkline of personal spend over 7d.

### 4.12 Portal · Playground
- Layout: left column = system prompt + params (sliders for temperature, max-tokens, etc), main = transcript, right rail = tools/MCP toggles.
- Stream tokens via SSE (`POST /api/v1/playground/run`).
- "Save as skill" button captures system prompt + params + tool list and sends to skills authoring flow.
- Persist transcript in localStorage keyed by session id; URL `?session=...`.

### 4.13 Portal · Prompts / Skills / Plugins / MCP / Models
- Card grids, hover lifts, click → detail Sheet. Each detail has a "Copy snippet" CTA producing a Python + TypeScript SDK call.

### 4.14 Portal · Keys
- Same key UI as admin team detail but scoped to the user.
- Rotation: creates new key, marks old as `rotating`, 7-day grace before revoke.

### 4.15 Portal · Usage
- 30-day stacked bar of spend (input + output + cache savings = negative bar).
- Filter by model + key + project tag.

### 4.16 Portal · Docs
- MDX content. Left TOC, right "On this page" anchor list. Code samples use `<CodeBlock>`.

---

## 5. API endpoints (minimum set)

```
# Auth
GET    /api/v1/me                                  -> { user, roles, teams }

# Teams + members + keys
GET    /api/v1/teams                               -> Team[]
GET    /api/v1/teams/{id}
POST   /api/v1/teams
PATCH  /api/v1/teams/{id}
GET    /api/v1/teams/{id}/members
POST   /api/v1/teams/{id}/members
DELETE /api/v1/teams/{id}/members/{email}
GET    /api/v1/teams/{id}/keys
POST   /api/v1/teams/{id}/keys                     -> { id, secret }   # secret returned ONCE
POST   /api/v1/teams/{id}/keys/{kid}/rotate
DELETE /api/v1/teams/{id}/keys/{kid}

# Policies + Guardrails + Quotas + Approvals
GET    /api/v1/policies; /api/v1/policies/{id}; PATCH; POST :version
GET    /api/v1/guardrails; PATCH order; POST :test
GET    /api/v1/quotas; PATCH /api/v1/quotas/{teamId}
GET    /api/v1/approvals?status=pending; POST /api/v1/approvals/{id}:approve|reject

# Catalog
GET    /api/v1/models                  GET    /api/v1/models/{id}/health
GET    /api/v1/mcp                     GET    /api/v1/mcp/{id}/health         POST /api/v1/mcp/{id}:reconnect
GET    /api/v1/skills                  POST   /api/v1/skills (publish)        POST /api/v1/skills/{id}:freeze
GET    /api/v1/plugins                 POST   /api/v1/plugins/{id}:install    POST :uninstall
GET    /api/v1/cache/config            PATCH
GET    /api/v1/providers               PATCH /api/v1/providers/{id}

# Operate
GET    /api/v1/requests?team=&...      GET    /api/v1/requests/stream  (SSE)
GET    /api/v1/alerts; POST /api/v1/alerts/{id}:ack
GET    /api/v1/audit; GET /api/v1/audit/export (returns job id)

# Portal
POST   /api/v1/playground/run          (SSE; body: messages, params, tools)
GET    /api/v1/usage/me?range=
GET    /api/v1/prompts; /api/v1/agents
```

All write endpoints return `{ id, etag }`. Use ETag + `If-Match` on PATCH/PUT.

---

## 6. Theming

Two CSS files contain all tokens. **Do not invent new colors.** Map:

```
--bg, --surface, --surface-2, --surface-3 -> Tailwind bg-*
--ink, --ink-2, --muted                   -> text-*
--border, --border-2                      -> border-*
--brand, --brand-2, --accent              -> brand utilities
--good, --warn, --bad, --info             -> status utilities
```

Dark mode is **default on** for both surfaces (set `data-theme="dark"` on `<html>`). Light mode toggles via the topbar sun/moon button; persist to `localStorage["aigw-theme"]`.

The portal has additional saturated overrides in `portal/reskin-portal.css` (gradient KPI numbers, distinct tile gradients per quick action). Keep those CSS variables intact when porting.

---

## 7. Accessibility

- Every interactive element has a focus ring (`:focus-visible` outline 2px solid `--brand`).
- Tables: row click is mirrored on Enter; selection checkboxes have `aria-label="Select row"`.
- Modals/Sheets: focus trap, Escape closes, return focus to trigger.
- Color contrast: status pills must clear 4.5:1 on `--surface`; verify with axe in CI.
- All charts have an `aria-label` describing the metric and time range and a hidden `<table>` with the underlying data.

---

## 8. Testing & acceptance

- **Unit:** Vitest. Cover every component in `apps/ui/components/` with at least one snapshot + one interaction test.
- **E2E:** Playwright. One spec per page; assertions:
  1. Renders without console errors.
  2. KPI strip values come from `/api/v1/...` mocks.
  3. Filter changes update query string and table rows.
  4. Primary CTA opens its dialog/sheet and submits successfully against MSW handlers.
- **Visual regression:** Chromatic on the Storybook for `apps/ui/components/`.
- **Definition of done per page:**
  - Mock layout matched at 1440×900 within 4px tolerance (use `prototype/*.html` as the reference; Playwright `toHaveScreenshot` against fixtures).
  - All copy strings match the mock (no lorem).
  - Empty / loading / error states implemented.
  - Keyboard navigable end-to-end.
  - Lighthouse a11y ≥ 95.

---

## 9. Icon mapping (mock SVG → lucide)

```
grid -> LayoutGrid     pulse -> Activity        users -> Users
key  -> Key            shield -> Shield         shieldcheck -> ShieldCheck
cube -> Box            database -> Database     plug -> Plug
log  -> ClipboardList  bell -> Bell             search -> Search
sun  -> Sun            moon -> Moon             gauge -> Gauge
inbox -> Inbox         mcp -> Plug2             spark2 -> Sparkles
puzzle -> Puzzle
```

---

## 10. Repository layout to produce

```
apps/
  admin/          # Next.js — /admin/*
  portal/         # Next.js — /portal/*
packages/
  ui/             # shared components, tokens, tailwind preset
  contracts/      # zod schemas + generated OpenAPI types
  charts/         # Recharts wrappers + Sparkline
  hooks/          # useTeams, useStream, useEditMode, ...
services/
  admin/          # FastAPI service exposing /api/v1/*
prototype/        # the HTML mock — keep, do not delete; CI compares pages
```

---

## 11. Phasing (suggested PRs)

1. **PR1 — Foundations.** packages/ui (Shell, Topbar, FilterBar, KpiCard, DataTable, Pill, Sparkline) + tokens + Storybook.
2. **PR2 — Admin overview.** Dashboard + Live requests + Teams list. MSW data.
3. **PR3 — Admin govern.** Team detail, Policies, Guardrails, Quotas, Approvals.
4. **PR4 — Admin catalog.** Models, MCP, Skills, Plugins, Cache, Providers.
5. **PR5 — Admin operate.** Alerts, Audit log.
6. **PR6 — Portal.** Home, Playground (SSE), Keys, Usage, Models, Docs.
7. **PR7 — Portal build.** Prompts, Agents, MCP, Skills, Plugins.
8. **PR8 — Polish.** Visual regression, a11y sweep, edge cases.

Each PR is a green Vercel preview deploy.

---

## 12. Open questions for the platform team

1. Authoritative source for team membership — Entra group sync direction?
2. Audit retention policy — confirm 7y WORM vs current 3y in spec.
3. Billing currency consolidation (USD vs EUR mixed in mocks).
4. Plugin source-of-truth — internal registry vs npm-style external?
5. SLA targets for the approvals queue (currently 24/72h hardcoded).

---

**End of spec.** When implementing a page, open the matching mock file in `prototype/` side-by-side, copy the exact markup structure into the React component tree, then wire data via React Query against MSW handlers seeded with the same example values shown in the mock.
