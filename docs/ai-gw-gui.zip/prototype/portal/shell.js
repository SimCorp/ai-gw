// Portal shell — renders sidebar + topbar
(function(){
  const NAV = [
    { group: null, items: [
      { id: 'home',       label: 'Home',         href: 'home.html',       icon: 'home' },
      { id: 'playground', label: 'Playground',   href: 'playground.html', icon: 'play', kbd: 'P' },
      { id: 'agents',     label: 'Agents',       href: 'agents.html',     icon: 'bot' },
    ]},
    { group: 'Build', items: [
      { id: 'keys',     label: 'API keys',      href: 'keys.html',     icon: 'key' },
      { id: 'models',   label: 'Models',        href: 'models.html',   icon: 'cube' },
      { id: 'prompts',  label: 'Prompts',       href: 'prompts.html',  icon: 'sparkles' },
      { id: 'mcp',      label: 'MCP servers',   href: 'mcp.html',      icon: 'plug' },
      { id: 'skills',   label: 'Skills',        href: 'skills.html',   icon: 'spark2' },
      { id: 'plugins',  label: 'Plugins',       href: 'plugins.html',  icon: 'puzzle' },
      { id: 'docs',     label: 'Quickstart',    href: 'docs.html',     icon: 'book' },
    ]},
    { group: 'Account', items: [
      { id: 'usage',    label: 'Usage & spend', href: 'usage.html',    icon: 'chart' },
      { id: 'team',     label: 'My team',       href: 'team.html',     icon: 'users' },
      { id: 'settings', label: 'Settings',      href: 'settings.html', icon: 'gear' },
    ]},
  ];

  const ICONS = {
    home:    '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M2 7l6-5 6 5v7H2V7z"/><path d="M6 14V9h4v5"/></svg>',
    play:    '<svg viewBox="0 0 16 16" fill="currentColor"><path d="M5 3.5v9l8-4.5-8-4.5z"/></svg>',
    bot:     '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="5" width="10" height="8" rx="2"/><path d="M8 2v3M5.5 9h0M10.5 9h0"/><path d="M1 8.5v2M15 8.5v2"/></svg>',
    key:     '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="5.5" cy="10.5" r="3"/><path d="M7.5 8.5L13 3M11 5l1.5 1.5"/></svg>',
    cube:    '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M8 1.5l5.5 3v7L8 14.5 2.5 11.5v-7L8 1.5z"/><path d="M2.5 4.5L8 7.5l5.5-3M8 7.5v7"/></svg>',
    sparkles:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M8 2v3M8 11v3M2 8h3M11 8h3M3.5 3.5l2 2M10.5 10.5l2 2M3.5 12.5l2-2M10.5 5.5l2-2"/></svg>',
    book:    '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M2.5 3.5h5a1 1 0 011 1v9a1 1 0 00-1-1h-5v-9zM13.5 3.5h-5a1 1 0 00-1 1v9a1 1 0 011-1h5v-9z"/></svg>',
    plug:    '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M5 2v3M11 2v3M3.5 5h9v3a4.5 4.5 0 01-9 0V5zM8 12.5V15"/></svg>',
    spark2:  '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M8 1.5l1.6 4.4 4.4 1.6-4.4 1.6L8 13.5 6.4 9.1 2 7.5l4.4-1.6L8 1.5z"/></svg>',
    puzzle:  '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M2.5 3.5h4v2a1.5 1.5 0 003 0v-2h4v4h-2a1.5 1.5 0 000 3h2v4h-4v-2a1.5 1.5 0 00-3 0v2h-4v-4h2a1.5 1.5 0 000-3h-2v-4z"/></svg>',
    chart:   '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M2 14h12M4 11V7M7 11V4M10 11V8M13 11V6"/></svg>',
    users:   '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="6" cy="6" r="2.5"/><path d="M2 13c0-2 2-3.5 4-3.5s4 1.5 4 3.5"/><circle cx="11" cy="5.5" r="2"/><path d="M10.5 9.5c2 0 3.5 1.5 3.5 3.5"/></svg>',
    gear:    '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="8" cy="8" r="2"/><path d="M8 1.5v2M8 12.5v2M1.5 8h2M12.5 8h2M3.3 3.3l1.4 1.4M11.3 11.3l1.4 1.4M3.3 12.7l1.4-1.4M11.3 4.7l1.4-1.4"/></svg>',
  };

  function render() {
    const slot = document.querySelector('[data-portal-shell]');
    if (!slot) return;
    const active = document.body.dataset.page;

    slot.innerHTML = `
      <aside class="psidebar">
        <div class="psidebar__brand">
          <div class="logo">SC</div>
          <div>
            <div class="name">AI Portal</div>
            <div class="sub">SimCorp · developer</div>
          </div>
        </div>
        <nav class="psidebar__nav">
          ${NAV.map(g => `
            ${g.group ? `<div class="group">${g.group}</div>` : '<div style="height:6px"></div>'}
            ${g.items.map(i => `
              <a href="${i.href}" class="${active === i.id ? 'is-active' : ''}">
                ${ICONS[i.icon] || ''}
                <span>${i.label}</span>
                ${i.kbd ? `<span class="kbd">${i.kbd}</span>` : ''}
              </a>
            `).join('')}
          `).join('')}
        </nav>
        <div class="psidebar__user">
          <span class="avatar" style="background:#1D958E">MW</span>
          <div class="who">
            <div class="name">Maja Weber</div>
            <div class="team">agent-platform</div>
          </div>
          <button class="icon-btn" style="width:24px;height:24px" title="Sign out">
            <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M9.5 11.5L13 8L9.5 4.5M13 8H5M5 2.5H2.5v11H5"/></svg>
          </button>
        </div>
      </aside>
    `;
  }
  document.addEventListener('DOMContentLoaded', render);
})();
