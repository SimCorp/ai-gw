/* AI Gateway Tweaks panel — wraps tweaks-panel.jsx primitives.
   Loads after react/babel + tweaks-panel.jsx. Persists to localStorage
   AND posts to host (__edit_mode_set_keys) so toolbar stays in sync.
*/
const { useEffect } = React;

function AIGWTweaks() {
  const defaults = /*EDITMODE-BEGIN*/{
    "theme": "light",
    "density": "comfortable",
    "accent": "#083EA7",
    "sidebarStyle": "labeled"
  }/*EDITMODE-END*/;

  // local state mirrors the global tweaks
  const seed = {
    theme: localStorage.getItem('aigw-theme') || defaults.theme,
    density: localStorage.getItem('aigw-density') || defaults.density,
    accent: localStorage.getItem('aigw-accent') || defaults.accent,
    sidebarStyle: localStorage.getItem('aigw-sidebar') || defaults.sidebarStyle,
  };
  const [t, setTweak] = useTweaks(seed);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', t.theme);
    localStorage.setItem('aigw-theme', t.theme);
  }, [t.theme]);

  useEffect(() => {
    document.body.classList.toggle('density-compact', t.density === 'compact');
    localStorage.setItem('aigw-density', t.density);
  }, [t.density]);

  useEffect(() => {
    document.documentElement.style.setProperty('--sc-blue', t.accent);
    // derive a soft tint
    document.documentElement.style.setProperty('--sc-blue-soft', t.accent + '1A');
    localStorage.setItem('aigw-accent', t.accent);
  }, [t.accent]);

  useEffect(() => {
    document.documentElement.classList.toggle('sidebar-icon-only', t.sidebarStyle === 'icons');
    localStorage.setItem('aigw-sidebar', t.sidebarStyle);
  }, [t.sidebarStyle]);

  return (
    <TweaksPanel title="Tweaks" subtitle="Theme · density · accent">
      <TweakSection title="Appearance">
        <TweakRadio label="Theme" value={t.theme} onChange={v => setTweak('theme', v)}
          options={[{value: 'light', label: 'Light'}, {value: 'dark', label: 'Dark'}]} />
        <TweakRadio label="Density" value={t.density} onChange={v => setTweak('density', v)}
          options={[{value: 'comfortable', label: 'Comfortable'}, {value: 'compact', label: 'Compact'}]} />
      </TweakSection>
      <TweakSection title="Brand">
        <TweakColor label="Accent" value={t.accent} onChange={v => setTweak('accent', v)}
          options={['#083EA7', '#0A7BD7', '#1D958E', '#4B17B6', '#1A1D31']} />
      </TweakSection>
    </TweaksPanel>
  );
}

const root = document.getElementById('tweaks-root') || (() => {
  const d = document.createElement('div'); d.id = 'tweaks-root'; document.body.appendChild(d); return d;
})();
ReactDOM.createRoot(root).render(<AIGWTweaks />);
