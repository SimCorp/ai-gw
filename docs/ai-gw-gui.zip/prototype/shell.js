/* Shared shell injector for AI Gateway Admin prototype.
   Renders sidebar + topbar into elements with [data-shell] and [data-topbar].
   Page declares its active nav via <body data-page="dashboard|teams|requests|audit|models|policies">.
*/
(function() {
  const NAV = [
    { group: 'Overview', items: [
      { id: 'dashboard', label: 'Dashboard',     href: 'dashboard.html', icon: 'grid' },
      { id: 'requests',  label: 'Live requests', href: 'requests.html',  icon: 'pulse' },
    ]},
    { group: 'Govern', items: [
      { id: 'teams',     label: 'Teams',         href: 'teams.html',     icon: 'users' },
      { id: 'policies',  label: 'Policies',      href: 'policies.html',  icon: 'shield' },
      { id: 'guardrails',label: 'Guardrails',    href: 'guardrails.html',icon: 'shieldcheck' },
      { id: 'quotas',    label: 'Quotas & budgets', href: 'quotas.html', icon: 'gauge' },
      { id: 'approvals', label: 'Approvals',     href: 'approvals.html', icon: 'inbox' },
    ]},
    { group: 'Catalog', items: [
      { id: 'models',    label: 'Model registry', href: 'models.html',    icon: 'cube' },
      { id: 'mcp',       label: 'MCP servers',    href: 'mcp.html',       icon: 'mcp' },
      { id: 'skills',    label: 'Skills',         href: 'skills.html',    icon: 'spark2' },
      { id: 'plugins',   label: 'Plugins',        href: 'plugins.html',   icon: 'puzzle' },
      { id: 'cache',     label: 'Cache',          href: 'cache.html',     icon: 'database' },
      { id: 'providers', label: 'Providers',      href: 'providers.html', icon: 'plug' },
    ]},
    { group: 'Audit', items: [
      { id: 'audit',     label: 'Audit log',      href: 'audit.html',  icon: 'log' },
      { id: 'alerts',    label: 'Alerts',         href: 'alerts.html', icon: 'bell' },
    ]},
  ];

  const ICON = {
    grid: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="2" width="5" height="5" rx="1"/><rect x="9" y="2" width="5" height="5" rx="1"/><rect x="2" y="9" width="5" height="5" rx="1"/><rect x="9" y="9" width="5" height="5" rx="1"/></svg>',
    pulse:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M1 8h3l2-5 3 10 2-5h4"/></svg>',
    users:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="6" cy="6" r="2.5"/><path d="M1.5 13.5c0-2.5 2-4 4.5-4s4.5 1.5 4.5 4"/><circle cx="11.5" cy="5" r="1.8"/><path d="M10.5 9.5c2 0 4 1 4 3.5"/></svg>',
    key:  '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="5" cy="8" r="3"/><path d="M8 8h7M12 8v3M14 8v2"/></svg>',
    shield:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"><path d="M8 1.5l5.5 2v4.2c0 3.3-2.3 5.6-5.5 6.8-3.2-1.2-5.5-3.5-5.5-6.8V3.5L8 1.5z"/></svg>',
    cube: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"><path d="M8 1.5l6 3v7l-6 3-6-3v-7l6-3z"/><path d="M2 4.5L8 7.5l6-3M8 7.5v7"/></svg>',
    database:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><ellipse cx="8" cy="3.5" rx="5.5" ry="2"/><path d="M2.5 3.5v9c0 1.1 2.5 2 5.5 2s5.5-.9 5.5-2v-9M2.5 8c0 1.1 2.5 2 5.5 2s5.5-.9 5.5-2"/></svg>',
    plug: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M5 1v4M11 1v4M3 5h10v3a5 5 0 01-10 0V5zM8 13v2"/></svg>',
    log:  '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><rect x="2.5" y="1.5" width="11" height="13" rx="1"/><path d="M5 5h6M5 8h6M5 11h4"/></svg>',
    bell: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M3.5 12h9l-1-2V7a3.5 3.5 0 00-7 0v3l-1 2zM6.5 14a1.5 1.5 0 003 0"/></svg>',
    shieldcheck: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"><path d="M8 1.5l5.5 2v4.2c0 3.3-2.3 5.6-5.5 6.8-3.2-1.2-5.5-3.5-5.5-6.8V3.5L8 1.5z"/><path d="M5.5 8l2 2 3-3.5"/></svg>',
    gauge:  '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M2 11a6 6 0 1112 0"/><path d="M8 11l3-3"/><circle cx="8" cy="11" r="1" fill="currentColor"/></svg>',
    inbox:  '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"><path d="M2 9l1.5-6h9L14 9v4H2V9z"/><path d="M2 9h3l1 1.5h4L11 9h3"/></svg>',
    mcp:    '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M5 2v3M11 2v3M3.5 5h9v3a4.5 4.5 0 01-9 0V5zM8 12.5V15"/></svg>',
    spark2: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"><path d="M8 1.5l1.6 4.4 4.4 1.6-4.4 1.6L8 13.5 6.4 9.1 2 7.5l4.4-1.6L8 1.5z"/></svg>',
    puzzle: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"><path d="M2.5 3.5h4v2a1.5 1.5 0 003 0v-2h4v4h-2a1.5 1.5 0 000 3h2v4h-4v-2a1.5 1.5 0 00-3 0v2h-4v-4h2a1.5 1.5 0 000-3h-2v-4z"/></svg>',
    search:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="7" cy="7" r="4.5"/><path d="M10.5 10.5L14 14"/></svg>',
    sun:  '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><circle cx="8" cy="8" r="3"/><path d="M8 1v1.5M8 13.5V15M1 8h1.5M13.5 8H15M3 3l1 1M12 12l1 1M3 13l1-1M12 4l1-1"/></svg>',
  };

  function renderSidebar(activeId) {
    const groups = NAV.map(g => `
      <div class="sidebar__group">
        <div class="sidebar__label">${g.group}</div>
        <div class="sidebar__nav">
          ${g.items.map(it => `
            <a href="${it.href}" class="${it.id === activeId ? 'is-active' : ''}">
              <span class="ico">${ICON[it.icon] || ''}</span>
              <span>${it.label}</span>
            </a>
          `).join('')}
        </div>
      </div>
    `).join('');

    return `
      <aside class="sidebar">
        <div class="sidebar__brand">
          <div class="sidebar__logo">SC</div>
          <div class="sidebar__brand-text">
            <span class="sidebar__brand-name">AI Gateway</span>
            <span class="sidebar__brand-sub">SimCorp Platform</span>
          </div>
        </div>
        ${groups}
        <div class="sidebar__bottom">
          <div class="sidebar__user">
            <div class="sidebar__avatar">MR</div>
            <div class="sidebar__user-meta">
              <div class="sidebar__user-name">Mira Rasmussen</div>
              <div class="sidebar__user-role">Platform admin</div>
            </div>
          </div>
        </div>
      </aside>
    `;
  }

  function renderTopbar(crumbs) {
    const c = (crumbs || []).map((p, i, a) => i === a.length - 1
      ? `<span class="now">${p.label}</span>`
      : `<a href="${p.href || '#'}">${p.label}</a><span class="sep">/</span>`
    ).join(' ');
    return `
      <div class="crumbs">${c}</div>
      <div class="topbar__spacer"></div>
      <span class="env-pill"><span class="dot"></span>prod · eu-north</span>
      <div class="search">
        <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="7" cy="7" r="4.5"/><path d="M10.5 10.5L14 14"/></svg>
        <input placeholder="Search teams, keys, requests…" />
        <kbd>⌘K</kbd>
      </div>
      <button class="icon-btn" title="Notifications">${ICON.bell}</button>
    `;
  }

  function init() {
    const body = document.body;
    const active = body.dataset.page || '';
    const crumbs = JSON.parse(body.dataset.crumbs || '[]');

    const shellEl = document.querySelector('[data-shell]');
    if (shellEl) shellEl.outerHTML = renderSidebar(active);

    const topEl = document.querySelector('[data-topbar]');
    if (topEl) topEl.innerHTML = renderTopbar(crumbs);

    // theme + density from localStorage
    const theme = localStorage.getItem('aigw-theme') || 'dark';
    const dens  = localStorage.getItem('aigw-density') || 'comfortable';
    document.documentElement.setAttribute('data-theme', theme);
    if (dens === 'compact') document.body.classList.add('density-compact');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
